public class Books {

    private int id;
    private String title;
    private String author;

    public Books(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
    }

    @Override
    public String toString() {
        return id + " " + title + " " + author;
    }
}